<?php $form_path='questionpaper_files/formoid1/form.php'; require_once $form_path; ?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>My Formoid form</title>
</head>
<body style="background-color:#EBEBEB">

{{Formoid}}

</body>
</html>
