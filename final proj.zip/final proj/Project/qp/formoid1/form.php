<?php

define('EMAIL_FOR_REPORTS', 'rahul.kulkarni1994@gmail.com');
define('RECAPTCHA_PRIVATE_KEY', '@privatekey@');
define('FINISH_URI', 'http://');
define('FINISH_ACTION', 'message');
define('FINISH_MESSAGE', 'Thanks for filling out my form!');
define('UPLOAD_ALLOWED_FILE_TYPES', 'doc, docx, xls, csv, txt, rtf, html, zip, jpg, jpeg, png, gif');

require_once str_replace('\\', '/', __DIR__) . '/handler.php';

?>

<link rel="stylesheet" href="<?=dirname($form_path)?>/formoid-default.css" type="text/css" />
<? if (frmd_message()): ?>
<span class="alert alert-success"><?=FINISH_MESSAGE;?></span>
<? else: ?>
<!-- Start Formoid form-->
<link rel="stylesheet" href="<?=dirname($form_path)?>/formoid-default.css" type="text/css" />
<script type="text/javascript" src="<?=dirname($form_path)?>/jquery.min.js"></script>
<form enctype="multipart/form-data" class="formoid-default" style="background-color:#FFFFFF;font-size:14px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#666666;width:480px" title="My Formoid form" method="post">
	<div class="element-text" ><h2 class="title">Question Papers</h2></div>
	<div class="element-multiple" ><label class="title">Semester</label><select name="multiple1[]" multiple="multiple" >

		<option value="1">1</option><br/>
		<option value="2">2</option><br/>
		<option value="3">3</option><br/>
		<option value="4">4</option><br/>
		<option value="5">5</option><br/>
		<option value="6">6</option><br/></select></div>
	<div class="element-multiple" ><label class="title">Subject</label><select name="multiple[]" multiple="multiple" >

		<option value="options 1">options 1</option><br/>
		<option value="options 2">options 2</option><br/>
		<option value="options 3">options 3</option><br/></select></div>
	<div class="element-multiple" ><label class="title">Year</label><select name="multiple2[]" multiple="multiple" >

		<option value="2014">2014</option><br/>
		<option value="2013">2013</option><br/>
		<option value="2012">2012</option><br/>
		<option value="2011">2011</option><br/>
		<option value="2010">2010</option><br/></select></div>
	<div class="element-file" ><label class="title">File</label><input type="file" name="file" /></div>
	<div class="element-submit" ><input type="submit" value="Submit"/></div>

</form>
<script type="text/javascript" src="<?=dirname($form_path)?>/formoid-default.js"></script>

<p class="frmd"><a href="http://formoid.com/">Web 2 0 Forms Formoid.com 1.9</a></p>
<!-- Stop Formoid form-->
<? endif; ?>

<?php frmd_end_form(); ?>