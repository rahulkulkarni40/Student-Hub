<?php 
$pass1=$_POST['password'];
$pass2=$_POST['password1'];

if($pass1 == $pass2)
{
$con=mysqli_connect('localhost','root','','student_hub');

if(mysqli_connect_error())

{
	
	echo"could not connect:".mysqli_connect_error();

}
	

$sql ="insert into admin(Id,Fullname,Username,Address,Email,Contact,Password) values ('$_POST[id]','$_POST[fn]','$_POST[un]','$_POST[add]','$_POST[email]','$_POST[con]','$_POST[password]')";
$result=mysqli_query($con,$sql);
	echo'<script>window.location="login.html"</script>';
}
else
{
	
	echo'<script type="text/javascript">';
	echo'alert("please enter same password")';
	echo'$pass.value=""';
	echo'$pass1.value=""';
	echo'$pass.focus()';
	echo'$pass1.focus()';
	echo'</script>';
	echo'<script> window.location="adcreate.html"</script>';
}


mysqli_close($con);
?>
